<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discrepancia extends Model
{
    protected $table = 'discrepancias';
}
