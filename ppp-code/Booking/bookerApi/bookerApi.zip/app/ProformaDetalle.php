<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProformaDetalle extends Model
{
    protected $table = 'proforma_detalle';
}
