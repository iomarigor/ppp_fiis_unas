<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoFormaPago extends Model
{
    protected $table = 'tipo_forma_pago';
}
