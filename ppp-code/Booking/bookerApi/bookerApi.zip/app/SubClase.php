<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubClase extends Model
{
    protected $table = 'sub_clase';
}
