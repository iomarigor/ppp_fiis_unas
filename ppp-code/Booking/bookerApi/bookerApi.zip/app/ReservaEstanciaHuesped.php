<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReservaEstanciaHuesped extends Model
{
    protected $table = 'reserva_estancia_huesped';
}
