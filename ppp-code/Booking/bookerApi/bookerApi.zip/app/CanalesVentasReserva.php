<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CanalesVentasReserva extends Model
{
    protected $table = 'canales_venta_reserva';
}
