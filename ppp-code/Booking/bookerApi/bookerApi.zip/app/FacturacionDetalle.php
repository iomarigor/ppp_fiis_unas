<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FacturacionDetalle extends Model
{
    protected $table = 'facturacion_detalle';
}
