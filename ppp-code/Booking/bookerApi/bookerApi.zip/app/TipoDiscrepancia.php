<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoDiscrepancia extends Model
{
    protected $table = 'tipo_discrepancia';
}
