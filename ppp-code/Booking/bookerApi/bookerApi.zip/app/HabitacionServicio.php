<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HabitacionServicio extends Model
{
    protected $table = 'habitacion_servicio';
}
