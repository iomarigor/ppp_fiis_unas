<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ZonaProduccionDetalle extends Model
{
    protected $table = 'zona_produccion_detalle';
}