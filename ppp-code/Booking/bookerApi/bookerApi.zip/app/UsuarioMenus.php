<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsuarioMenus extends Model
{
    protected $table = 'usuario_menus';
    protected $fillable = ['usuario_menus'];
}
