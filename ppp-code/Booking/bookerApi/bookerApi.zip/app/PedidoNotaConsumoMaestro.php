<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PedidoNotaConsumoMaestro extends Model
{
    protected $table = 'pedido_nota_consumo_maestro';
}
