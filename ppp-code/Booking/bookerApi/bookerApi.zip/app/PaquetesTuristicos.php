<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaquetesTuristicos extends Model
{
    protected $table = 'paquetes_turisticos';
}
