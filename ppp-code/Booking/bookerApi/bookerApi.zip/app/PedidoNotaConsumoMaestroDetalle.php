<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PedidoNotaConsumoMaestroDetalle extends Model
{
    protected $table = 'pedido_nota_consumo_maestro_detalle';
}
