<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstablecimientoSucursal extends Model
{
    protected $table = 'establecimiento_sucursal';
}
