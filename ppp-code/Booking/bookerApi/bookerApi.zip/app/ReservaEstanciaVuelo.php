<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReservaEstanciaVuelo extends Model
{
    protected $table = 'reserva_estancia_vuelo';
}
