<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClaseHabitacion extends Model
{
    protected $table = 'clase_habitacion';
}
