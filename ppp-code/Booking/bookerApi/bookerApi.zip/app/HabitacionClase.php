<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HabitacionClase extends Model
{
    protected $table = 'habitacion_clase';
}
