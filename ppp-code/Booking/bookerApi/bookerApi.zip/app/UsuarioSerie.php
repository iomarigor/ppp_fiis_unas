<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsuarioSerie extends Model
{
    protected $table = 'serie_comprobante_usuario';
}
