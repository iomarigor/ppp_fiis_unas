<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReservaEstanciaHabitacion extends Model
{
    protected $table = 'reserva_estancia_habitacion';
}
