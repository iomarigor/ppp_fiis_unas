<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UnidadMedidaProducto extends Model
{
    protected $table = 'unidadmedida_producto';
}
