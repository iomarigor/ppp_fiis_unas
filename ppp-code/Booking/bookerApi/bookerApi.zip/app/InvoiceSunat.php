<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceSunat extends Model
{
    protected $table = 'invoice_sunat';
}