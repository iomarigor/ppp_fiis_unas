<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HabitacionCama extends Model
{
    protected $table = 'habitacion_cama';
}
