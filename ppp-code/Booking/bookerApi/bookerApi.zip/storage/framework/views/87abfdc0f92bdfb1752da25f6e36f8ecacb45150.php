<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ficha de reserva</title>
    <style>
    body {
        font: 10px Arial, Tahoma, Verdana, Helvetica, sans-serif;
        color: #000;
    }


    img {
        width: 100%;
    }
    </style>
</head>

<body>
    <img src="<?php echo e($data['logo']); ?>" alt="logo" />
    <h4>Reserva estancia Tampu</h4>
    <p>Buenos dias <?php echo e($data['nameUser']); ?></p>
    <p><?php echo e($data['detalle']); ?></p>
    <h5>Link de registor de huespedes: <?php echo e($data['urlSend']); ?></h5>
    <p><?php echo e($data['logo']); ?></p>
</body>

</html><?php /**PATH /home/bqjx6hb4dyei/public_html/tampu.accordtechsoft.com/bookerApi/resources/views/emails/EmailReserva.blade.php ENDPATH**/ ?>